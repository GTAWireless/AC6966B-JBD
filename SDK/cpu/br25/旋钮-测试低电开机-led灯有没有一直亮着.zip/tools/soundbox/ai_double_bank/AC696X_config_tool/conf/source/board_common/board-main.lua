
board_view_tabs = {}
board_output_text_tabs = {}
board_output_bin_tabs = {}


require("board_common.key_common");
require("board_common.key_msg");
require("board_common.audio_v1");
require("board_common.charge_v1");


board_view = {"通用配置",
	cfg:stTab(board_view_tabs);
};




